return decodeURIComponent(clipText);

