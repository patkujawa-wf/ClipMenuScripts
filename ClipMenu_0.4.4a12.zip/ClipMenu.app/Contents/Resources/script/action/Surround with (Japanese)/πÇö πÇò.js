return '〔' + clipText + '〕';

