return '‘' + clipText + '’';

