return '＜' + clipText + '＞';

