return '｛' + clipText + '｝';

