return '［' + clipText + '］';

