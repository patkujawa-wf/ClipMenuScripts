return '(' + clipText + ')';

